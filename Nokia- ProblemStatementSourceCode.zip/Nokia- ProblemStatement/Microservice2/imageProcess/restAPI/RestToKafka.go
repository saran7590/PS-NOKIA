package main

// @title Orders API
// @version 1.0
// @description This is a sample serice for managing orders
// @termsOfService http://swagger.io/terms/
// @contact.name API Support
// @contact.email soberkoder@swagger.io
// @license.name Apache 2.0
// @license.url http://www.apache.org/licenses/LICENSE-2.0.html
// @host localhost:8080
// @BasePath /

import (
	"encoding/json"
	"fmt"
	"github.com/gorilla/mux"
	"gopkg.in/confluentinc/confluent-kafka-go.v1/kafka"
	_ "gopkg.in/mgo.v2"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"
	"time"
)

const (
	hosts      = "localhost:27017"
	database   = "db"
	username   = ""
	password   = ""
	collection = "jobs"
)

var orders = make([]Order,0)

type Job struct {
	Title       string `json:"title"`
	Description string `json:"description"`
	Company     string `json:"company"`
	Salary      string `json:"salary"`
}
type AlbumDetails struct {
	Title       string `json:"title"`
	Description string `json:"description"`
	TotalImage     string `json:"totalImage"`
	ImageType      string `json:"imageType"`
	AlbumId          string `json:"albumId"`
}

type ImageData struct {
	ImageTitle       string `json:"Imagetitle"`
	Description string `json:"description"`
	ImageData     string `json:"imageData"`
	ImageType      string `json:"imageType"`
	AlbumId          string `json:"albumId"`
}

// Order represents the model for an order
type Order struct {
	OrderID      string    `json:"orderId" example:"1"`
	CustomerName string    `json:"customerName" example:"Leo Messi"`
	OrderedAt    time.Time `json:"orderedAt" example:"2019-11-09T21:21:46+00:00"`
	Items        []Item    `json:"items"`
}

// Item represents the model for an item in the order
type Item struct {
	ItemID      string `json:"itemId" example:"A1B2C3"`
	Description string `json:"description" example:"A random description"`
	Quantity    int    `json:"quantity" example:"1"`
}
func main() {

	router := mux.NewRouter().StrictSlash(true)
	println("STARTING SERVER")
	//router.HandleFunc("/jobs", jobsPostHandler).Methods("POST")
	router.HandleFunc("/createImage", imageCreation).Methods("POST")
	router.HandleFunc("/getImage", imageCreation).Methods("POST")
	router.HandleFunc("/swagger.json", swagger).Methods("GET")
	router.HandleFunc("/hello/{name}", index).Methods("GET")
	log.Fatal(http.ListenAndServe(":8080", router))

}
// GetOrders godoc
// @Summary Get details of all orders
// @Description Get details of all orders
// @Tags orders
// @Accept  json
// @Produce  json
// @Success 200 {array} Order
// @Router /orders [get]
func getOrders(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(orders)
}

// CreateOrder godoc
// @Summary Create a new order
// @Description Create a new order with the input paylod
// @Tags orders
// @Accept  json
// @Produce  json
// @Param order body Order true "Create order"
// @Success 200 {object} Order
// @Router /orders [post]
func createOrder(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	prevOrderID :=0

	var order Order
	json.NewDecoder(r.Body).Decode(&order)
	prevOrderID++
	order.OrderID = strconv.Itoa(prevOrderID)
	orders = append(orders, order)
	json.NewEncoder(w).Encode(order)
}


func swagger(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	http.ServeFile(w, r, "swagger.json")
}

// swagger:operation GET /hello/{name} hello Hello
//
// Returns a simple Hello message
// ---
// consumes:
// - text/plain
// produces:
// - text/plain
// parameters:
// - name: name
//   in: path
//   description: Name to be returned.
//   required: true
//   type: string
// responses:
//   '200':
//     description: The hello message
//
func index(w http.ResponseWriter, r *http.Request) {
	log.Println("Responsing to /hello request")
	log.Println(r.UserAgent())

	vars := mux.Vars(r)
	name := vars["name"]

	w.WriteHeader(http.StatusOK)
	fmt.Fprintln(w, "Hello:", name)
}
func imageCreation(w http.ResponseWriter, r *http.Request) {

	//Retrieve body from http request
	b, err := ioutil.ReadAll(r.Body)
	defer r.Body.Close()
	if err != nil {
		panic(err)
	}

	//Save data into Job struct
	var img ImageData
	err = json.Unmarshal(b, &img)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	saveJobToKafka(img)

	//Convert job struct into json
	jsonString, err := json.Marshal(img)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	//Set content-type http header
	w.Header().Set("content-type", "application/json")

	//Send back data as response
	w.Write(jsonString)

}



/*func jobsPostHandler(w http.ResponseWriter, r *http.Request) {

	//Retrieve body from http request
	b, err := ioutil.ReadAll(r.Body)
	defer r.Body.Close()
	if err != nil {
		panic(err)
	}

	//Save data into Job struct
	var _job Job
	err = json.Unmarshal(b, &_job)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	saveJobToKafka(_job)

	//Convert job struct into json
	jsonString, err := json.Marshal(_job)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	//Set content-type http header
	w.Header().Set("content-type", "application/json")

	//Send back data as response
	w.Write(jsonString)

}*/

func createAlbum(w http.ResponseWriter, r *http.Request){
	b, err := ioutil.ReadAll(r.Body)
	defer r.Body.Close()
	if err != nil {
		panic(err)
	}

	//Save data into Job struct
	var album AlbumDetails
	err = json.Unmarshal(b, &album)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
}

func saveJobToKafka(img ImageData) {

	fmt.Println("save to kafka")

	jsonString, err := json.Marshal(img)

	jobString := string(jsonString)
	fmt.Print(jobString)

	p, err := kafka.NewProducer(&kafka.ConfigMap{"bootstrap.servers": "localhost:9092"})
	if err != nil {
		panic(err)
	}

	// Produce messages to topic (asynchronously)
	topic := "add"
	for _, word := range []string{string(jobString)} {
		p.Produce(&kafka.Message{
			TopicPartition: kafka.TopicPartition{Topic: &topic, Partition: kafka.PartitionAny},
			Value:          []byte(word),
		}, nil)
	}
}

func delete(w http.ResponseWriter, r *http.Request) {

	//Retrieve body from http request
	b, err := ioutil.ReadAll(r.Body)
	defer r.Body.Close()
	if err != nil {
		panic(err)
	}

	//Save data into Job struct
	fmt.Println(string(b))
	/*var img ImageData
	err = json.Unmarshal(b, &img)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}*/

	deteleRequest(string(b))

	//Convert job struct into json
	//jsonString, err := json.Marshal(img)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	//Set content-type http header
	w.Header().Set("content-type", "application/json")

	//Send back data as response
	w.Write(b)

}

func deteleRequest(deleteRequest string) {

	fmt.Println("save to kafka")

	//jsonString, err := json.Marshal(img)

	//jobString := string(jsonString)
	//fmt.Print(jobString)

	p, err := kafka.NewProducer(&kafka.ConfigMap{"bootstrap.servers": "localhost:9092"})
	if err != nil {
		panic(err)
	}

	// Produce messages to topic (asynchronously)
	topic := "remove"
	for _, word := range []string{string(deleteRequest)} {
		p.Produce(&kafka.Message{
			TopicPartition: kafka.TopicPartition{Topic: &topic, Partition: kafka.PartitionAny},
			Value:          []byte(word),
		}, nil)
	}
}
