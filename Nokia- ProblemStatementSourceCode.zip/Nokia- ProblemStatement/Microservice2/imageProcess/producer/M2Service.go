package main

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-sdk-go/pkg/common/logging"
	"gopkg.in/mgo.v2/bson"
	"time"
	"gopkg.in/confluentinc/confluent-kafka-go.v1/kafka"
	"gopkg.in/mgo.v2"
)
var logger = logging.NewLogger("M2Service")

const (
	hosts      = "mongodb:27017"
	database   = "db"
	username   = ""
	password   = ""
	image_collection = "imageDetails"
	album_collection = "albumDetails"
)

type AlbumImageDetails struct {
	Image        string    `json:"image,omitempty"  bson:"image" example:"upload .jpg/.png"`
	ImageId 	 string    `json:"imageId,omitempty" bson:"imageId"  example:"101"`
	ImageName    string    `json:"imageName,omitempty" bson:"imageName" example:"test1.jpg/test2.png"`
	AlbumId      string    `json:"albumId,omitempty" bson:"albumId" example:"1234"`
	CreatedOn    string    `json:"createdOn,omitempty" bson:"createdOn" example:"10/10/2020"`
}
type AlbumDetails struct {
	AlbumName    	string    `json:"albumName,omitempty" bson:"albumName" example:"Album101"`
	AlbumId      	string    `json:"albumId,omitempty" bson:"albumId" example:"1"`
	MaxImageLimit 	int    	  `json:"maximagelimit,omitempty" bson:"maxImagelimit" example:"20"`
	CreatedOn       string    `json:"createdOn,omitempty" bson:"createdOn" example:"10/10/2020"`
}

type MongoStore struct {
	session *mgo.Session
}

var mongoStore = MongoStore{}

func main() {
	session := initialiseMongo()
	mongoStore.session = session
	receiveFromKafka()

}

func initialiseMongo() (session *mgo.Session) {
	info := &mgo.DialInfo{
		Addrs:    []string{hosts},
		Timeout:  60 * time.Second,
		Database: database,
		Username: username,
		Password: password,
	}
	session, err := mgo.DialWithInfo(info)
	if err != nil {
		logger.Error("Error during DB dial connection",err)
		panic(err)
	}
	return
}

func receiveFromKafka() {
	logger.Info("receiveFromKafka() starts---->")
		fmt.Println("Start receiving from Kafka")
		c, err := kafka.NewConsumer(&kafka.ConfigMap{
			"bootstrap.servers": "kafka1:9092",
			"group.id":          "group-id-1",
			"auto.offset.reset": "earliest",
		})
		if err != nil {
			logger.Error("Error while initialize the consumer ",err)
			return
		}
		c.SubscribeTopics([]string{"uploadImage","deleteImage","createAlbum","deleteAlbum"}, nil)
	for {
		msg, err := c.ReadMessage(-1)
		if err == nil {
			logger.Info("Received from Kafka %s: %s\n", msg.TopicPartition, string(msg.Value))
			job := string(msg.Value)
			saveJobToMongo(job,*msg.TopicPartition.Topic)
		} else {
			logger.Error("Consumer error: %v (%v)\n", err, msg)
			break
		}
	}
	defer mongoStore.session.Close()
	c.Close()
	logger.Info("receiveFromKafka() Ends---->")
}

func saveJobToMongo(jobString,request string) {
	logger.Info("saveJobToMongoDB() Starts---->")
	var albumImageDetails AlbumImageDetails
	var album AlbumDetails
	if request == "uploadImage"{
		b := []byte(jobString)
		err := json.Unmarshal(b, &albumImageDetails)
		if err != nil {
			logger.Error("Error during unmarshal-",err)
			return
		}
		col := mongoStore.session.DB(database).C(image_collection)
		errMongo := col.Insert(albumImageDetails)
		if errMongo != nil {
			logger.Error("Error during DB insert(Upload Image)",errMongo)
			return
		}
	}else if request == "deleteImage" {
		b := []byte(jobString)
		err := json.Unmarshal(b, &albumImageDetails)
		if err != nil {
			logger.Error("Error during unmarshal-",err)
			return
		}
		col := mongoStore.session.DB(database).C(image_collection)
		query :=  make(map[string]interface{})
		if albumImageDetails.AlbumId != ""  &&  albumImageDetails.ImageId != "" {
			query = bson.M{"imageId":albumImageDetails.ImageId,"albumId":albumImageDetails.AlbumId}
		}else{
			query = bson.M{"imageId":albumImageDetails.ImageId}
		}
		var imageDetails AlbumImageDetails
		errMongo := col.Find(query).One(&imageDetails)
		if errMongo != nil {
			logger.Error("Error during DB query execution",errMongo)
			return
		}
		errDb := col.Remove(&imageDetails)
		if errDb != nil {
	   		logger.Error("Error while removing the data(Image)",errDb)
	   		return
		}
	}else if request == "createAlbum"{
		bytes := []byte(jobString)
		err := json.Unmarshal(bytes, &album)
		if err != nil {
			logger.Error("Error during Unmarshal",err)
			return
		}
		col := mongoStore.session.DB(database).C(album_collection)
		errMongo := col.Insert(album)
		if errMongo != nil {
			logger.Error("Error while removing the data(Image)",errMongo)
			return
		}
	}else if request == "deleteAlbum"{
		b := []byte(jobString)
		err := json.Unmarshal(b, &album)
		if err != nil {
			panic(err)
		}
		if album.AlbumId != ""{
			col := mongoStore.session.DB(database).C(album_collection)
			query := bson.M{"albumId":album.AlbumId}
			var album1 AlbumDetails
			errMongo := col.Find(query).One(&album1)
			if errMongo != nil {
				logger.Error("Error during find query Album",errMongo)
				return
			}
			err := col.Remove(&album1)
			if err != nil {
				logger.Error("error during removing",err)
				return
			}
		}
	}
	logger.Info("Data saved successfully in Mongo DB : %s", jobString)
}
