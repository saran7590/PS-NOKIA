package main

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/gorilla/mux"
	"github.com/hyperledger/fabric-sdk-go/pkg/common/logging"
	httpSwagger "github.com/swaggo/http-swagger"
	"gopkg.in/confluentinc/confluent-kafka-go.v1/kafka"
	"gopkg.in/mgo.v2/bson"
	_ "imageAlbum-api/docs"
	"imageAlbum-api/docs/DBConnection"
	"io/ioutil"
	"log"
	"net/http"
	"time"
)
var logger = logging.NewLogger("Image uplaod")

const (
	image_collectionType = "image"
	album_collectionType = "album"
)


func main() {
	router := mux.NewRouter()
	router.HandleFunc("/album", createAlbum).Methods("POST")
	router.HandleFunc("/album/{albumId}", getAlbumDetails).Methods("GET")
	router.HandleFunc("/album/{albumId}", deleteAlbum).Methods("DELETE")
	router.HandleFunc("/image/{albumId}/{imageId}", deleteImage).Methods("DELETE")
	router.HandleFunc("/upload", upload).Methods("POST")
	router.HandleFunc("/image/{albumId}/{imageId}", getImageFromAlbum).Methods("GET")
	router.HandleFunc("/image/{albumId}", getImageFromAlbum).Methods("GET")
	router.PathPrefix("/swagger").Handler(httpSwagger.WrapHandler)
	log.Fatal(http.ListenAndServe(":8080", router))
}


func createAlbum(w http.ResponseWriter, r *http.Request) {
	logger.Info("createImageAlbum process starts -->")
	var albumDetails AlbumDetails
	u, _ := ioutil.ReadAll(r.Body)
	err := json.Unmarshal(u, &albumDetails)
	if err != nil{
		return
	}
	if albumDetails.AlbumId != "" && albumDetails.AlbumName != "" && albumDetails.MaxImageLimit >0{
		isAvailabile := validateAlbumnUniqueId(albumDetails.AlbumId)
		if !isAvailabile{
			albumDetails.CreatedOn = time.Now().Format("02-01-2006")
			jsonString, err := json.Marshal(albumDetails);if err != nil{
				logger.Error("Error occurs during JSON marshall",err)
				ReturnJSONAPIError(w,errors.New("Error during JSON marshall"),101)
				return
			}
			status,err := sendDataToKafka(string(jsonString),"createAlbum");if err != nil{
				logger.Error("Error occurs during sendDataToKafka",err)
				ReturnJSONAPIError(w,errors.New("Technical Error"),101)
				return
			}
			if status{
				ReturnJSONAPISuccess(w,"Album created successfully",nil)
				return
			}

		}else{
			ReturnJSONAPIError(w,errors.New("Album ID already in use. Please try with another id"),304)
			return
		}
	}else{
		ReturnJSONAPIError(w,errors.New("Mandatory field values are missing(AlbumID/AlbumName/Limit)"),303)
		return
	}
	defer logger.Info("createImageAlbum process Ends -->")
}


func getAlbumDetails(w http.ResponseWriter, r *http.Request){
	logger.Info("GetAlbumDetails--->Starts")
	w.Header().Set("Content-Type", "application/json")
	params := mux.Vars(r)
	albumId := params["albumId"]
	if albumId == "" {
		ReturnJSONAPIError(w,errors.New("AlbumId Cant be empty"),301)
		return
	}
	var albumDetails AlbumDetails
	query := bson.M{"albumId":albumId}
	err := DBConnection.QueryExecutorByOne(query,album_collectionType,&albumDetails)
	if err != nil {
		ReturnJSONAPIError(w,err,500)
		return
	}
	ReturnJSONAPISuccess(w,nil,albumDetails)
	defer logger.Info("GetAlbumDetails--->Starts")
}

func deleteAlbum(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type", "application/json")
	var albumDetails AlbumDetails
	params := mux.Vars(r)
	albumId  := ""
	if params["albumId"] != ""{
		albumId = params["albumId"]
		albumDetails.AlbumId = albumId
	}else{
		ReturnJSONAPIError(w,errors.New("AlbumId Cant be empty"),301)
		return
	}
	isAvailabile := validateAlbumnUniqueId(albumDetails.AlbumId)
	if isAvailabile{
		count,err := imageCount(albumDetails.AlbumId);if err != nil{
			fmt.Println("Error during image count",err)
			ReturnJSONAPIError(w,err,301)
			return
		}
		if count > 0 {
			ReturnJSONAPIError(w,errors.New("Album containing images.Please remove images before deleting albumn "),301)
			return
		}
		jsonString, _ := json.Marshal(albumDetails)
		status,err := sendDataToKafka(string(jsonString),"deleteAlbum");if err != nil{
			logger.Error("Error occurs during sendDataToKafka",err)
			ReturnJSONAPIError(w,errors.New("Technical Error"),500)
			return
		}
		if status{
			ReturnJSONAPISuccess(w,"Album sucessfully deleted",nil)
			return
		}
	}else{
		logger.Error("No data avaialbe")
		ReturnJSONAPIError(w,errors.New("No album against the given albumID"),302)
		return
	}
}

func getImage(w http.ResponseWriter, r *http.Request){
	logger.Info("GetAlbumDetails--->Starts")
	w.Header().Set("Content-Type", "application/json")
	var imageDetails AlbumImageDetails
	params := mux.Vars(r)
	inputOrderID := params["imageId"]
	if inputOrderID == ""{
		ReturnJSONAPIError(w,errors.New("Cant be empty"),303)
	}
	query := bson.M{"imageId":inputOrderID}
	err := DBConnection.QueryExecutorByOne(query,image_collectionType,&imageDetails)
	if err != nil {
		ReturnJSONAPIError(w,err,500)
		return
	}
	ReturnJSONAPISuccess(w,nil,imageDetails)
	defer logger.Info("GetAlbumDetails--->Starts")
}

func getImageFromAlbum(w http.ResponseWriter, r *http.Request){
	logger.Info("getImageFromAlbum() starts ")
		w.Header().Set("Content-Type", "application/json")
		var imageDetails []AlbumImageDetails
		imageId,albumId := "",""
		params := mux.Vars(r)
		query := make(map[string]interface{})
	 if params["imageId"] == ""  && params["albumId"] != ""{
		albumId = params["albumId"]
		query = bson.M{"albumId":albumId}
	}else if params["imageId"] != "" && params["albumId"] != ""{
		 imageId = params["imageId"]
		albumId = params["albumId"]
		query = bson.M{"imageId":imageId,"albumId":albumId}
	}else{
		 ReturnJSONAPIError(w, errors.New("Album Id/ImageId cant be empty"), 304)
		 return
	 }
	err := DBConnection.QueryExecutorByAll(query,image_collectionType,&imageDetails)
	if err != nil {
		ReturnJSONAPIError(w,err,500)
		return
	}
	if len(imageDetails) == 0{
		ReturnJSONAPIError(w, errors.New("No Images found in the given album ID"), 305)
		return
	}
	ReturnJSONAPISuccess(w,nil,imageDetails)
	defer logger.Info("GetAlbumDetails--->Starts")
	}

func deleteImage(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	var imageDetails AlbumImageDetails
	params := mux.Vars(r)
	if params["imageId"] != "" && params["albumId"] != "" {
		imageDetails.ImageId = params["imageId"]
		imageDetails.AlbumId = params["albumId"]
	} else {
		ReturnJSONAPIError(w, errors.New("Album Id/ImageId cant be empty"), 304)
		return
	}
	isAvailabile := validateAlbumnUniqueId(imageDetails.AlbumId)
	if isAvailabile {
		isAvailabile := validateImageUniqueId(imageDetails.ImageId)
		if isAvailabile {
			query := make(map[string]interface{})
			query = bson.M{"imageId": imageDetails.ImageId, "albumId": imageDetails.AlbumId}
			count, err := DBConnection.CountQueryExecutor(query, image_collectionType)
			if err != nil {
				ReturnJSONAPIError(w, err, 500)
				return
			}
			if count >= 1 {
				jsonString, _ := json.Marshal(imageDetails)
				status, err := sendDataToKafka(string(jsonString), "delete")
				if err != nil {
					logger.Error("Error occurs during sendDataToKafka", err)
					ReturnJSONAPIError(w, errors.New("Technical Error"), 600)
					return
				}
				if status {
					ReturnJSONAPISuccess(w, "Image deleted sucessfully in the ablum ", nil)
					return
				}
			} else {
				logger.Error("No data avaialbe")
				ReturnJSONAPIError(w, errors.New("ImageID and album ID is not matching.Please provide valid combination"), 104)
				return
			}
		} else {
		logger.Error("No data avaialbe")
		ReturnJSONAPIError(w, errors.New("No Image found against the given ID"), 102)
		return
	}
	} else {
		logger.Error("No data avaialbe")
		ReturnJSONAPIError(w, errors.New("No album found against the given ID"), 103)
		return
	}
}


func upload(w http.ResponseWriter, r *http.Request) {
	logger.Info("Upload process starts -->")
	file, handler, err := r.FormFile("fileUpload")
	if err != nil {
		fmt.Println("Error During Form file parse ",err)
		ReturnJSONAPIError(w,errors.New("Error occured during multifile parsing"),105)
		return
	}
	var imageDetails AlbumImageDetails
	if r.FormValue("imageId") != "" && r.FormValue("imageName") != "" && r.FormValue("albumId") != ""{
		imageDetails.ImageId = r.FormValue("imageId")
		imageDetails.ImageName = r.FormValue("imageName")
		imageDetails.AlbumId = r.FormValue("albumId")
	}else{
		ReturnJSONAPIError(w,errors.New("imageId/AlbumId/Name cant be empty"),106)
		return
	}
	defer file.Close()
	fmt.Printf("Uploaded File: %+v\n", handler.Filename)
	fmt.Printf("File Size: %+v\n", handler.Size)
	fmt.Printf("MIME Header: %+v\n", handler.Header["Content-Type"])
	contentType := handler.Header["Content-Type"][0]
	if handler.Size/1000 < 5000 {
		if contentType != "image/png" && contentType != "image/jpg" && contentType != "image/jpeg" {
			logger.Info("Invalid file format")
			ReturnJSONAPIError(w, errors.New("Invalid file format(Supports - JPEG,PNG,JPG)"), 141)
			return
		}
		isAvailabile := validateAlbumnUniqueId(imageDetails.AlbumId)
		if isAvailabile {
			isAvailabile := validateImageUniqueId(imageDetails.ImageId)
			if !isAvailabile{
				 imgmaxlimt,err := validateImagecount(imageDetails.AlbumId);if err !=nil{
						fmt.Println(err)
				}
				if imgmaxlimt {
					fileBytes, err := ioutil.ReadAll(file)
					if err != nil {
						fmt.Println(err)
					}
					str := base64.StdEncoding.EncodeToString(fileBytes)
					imageDetails.Image = str
					jsonString, err := json.Marshal(imageDetails);
					if err != nil {
						fmt.Println(err)
					}
					status, err := sendDataToKafka(string(jsonString), "upload")
					if err != nil {
						logger.Error("Error occurs during sendDataToKafka", err)
						ReturnJSONAPIError(w, err, 500)
						return
					}
					if status {
						ReturnJSONAPISuccess(w, "Image created sucessfully", nil)
						return
					}
				}else{
					ReturnJSONAPIError(w,errors.New("Album images are full. Album reached max limit"),110)
					return
				}
			}else{
				ReturnJSONAPIError(w,errors.New("ImageID already exists"),110)
				return
			}
		}else{
			ReturnJSONAPIError(w,errors.New("Albumn not available"),111)
			return
		}

	}else{
		ReturnJSONAPIError(w, errors.New("Size exceeds"), 112)
		return
	}
}

func sendDataToKafka(data,requestType string)(bool,error) {
	logger.Info("Send message Kafka Process starts")
	topic := ""
	switch requestType {
	case "upload":
		topic = "uploadImage"
		break
	case "delete":
		topic = "deleteImage"
		break
	case "createAlbum":
		topic = "createAlbum"
		break
	case "deleteAlbum":
		topic = "deleteAlbum"
		break
	default:
		logger.Info("No case found")
		return false,errors.New("Technincal issue.")
	}
	p, err := kafka.NewProducer(&kafka.ConfigMap{"bootstrap.servers": "localhost:9092"})
	if err != nil {
		return false,err
	}
	err = p.Produce(&kafka.Message{
		TopicPartition: kafka.TopicPartition{Topic: &topic, Partition: kafka.PartitionAny},
		Value:          []byte(data),
	}, nil)
	if err != nil{
		logger.Error("error when sending the message to kafka",err)
		return false,err
	}
	logger.Info("Send message Kafka Process starts")
	return  true,nil
}




type AlbumImageDetails struct {
	Image        string    `json:"image,omitempty"  bson:"image" example:"upload .jpg/.png"`
	ImageId 	 string    `json:"imageId,omitempty" bson:"imageId"  example:"101"`
	ImageName    string    `json:"imageName,omitempty" bson:"imageName" example:"test1.jpg/test2.png"`
	AlbumId      string    `json:"albumId,omitempty" bson:"albumId" example:"1234"`
	CreatedOn    string    `json:"createdOn,omitempty" bson:"createdOn" example:"10/10/2020"`
}
type AlbumDetails struct {
	AlbumName    	string    `json:"albumName,omitempty" bson:"albumName" example:"Album101"`
	AlbumId      	string    `json:"albumId,omitempty" bson:"albumId" example:"1"`
	MaxImageLimit 	int    	  `json:"maximagelimit,omitempty" bson:"maxImagelimit" example:"20"`
	CreatedOn       string    `json:"createdOn,omitempty" bson:"createdOn" example:"10/10/2020"`
}


func validateAlbumnUniqueId(value string,)(bool){
	logger.Info("validateAlbumnUniqueId starts")
	result := false
	query := make(map[string]interface{})
	query = bson.M{"albumId":value}
	count, err := DBConnection.CountQueryExecutor(query,"album");if err != nil{
		fmt.Println("error",err)
	}
	if count > 0 {
		result = true
	}
	defer logger.Info("validateAlbumnUniqueId Ends")
	return result
}

func validateImageUniqueId(value string)(bool){
	logger.Info("validateImageUniqueId starts")
	result := false
	query := make(map[string]interface{})
	query = bson.M{"imageId":value}
	count, err := DBConnection.CountQueryExecutor(query,"image");if err != nil{
		fmt.Println("error",err)
	}
	if count > 0 {
		result = true
	}
	defer logger.Info("validateImageUniqueId Ends")
	return result
}

func validateImagecount(value string)(bool,error){
	logger.Info("validateImagecount starts")
	result := false
	query := make(map[string]interface{})
	query = bson.M{"albumId":value}
	uploadedImg, err := DBConnection.CountQueryExecutor(query,"image");if err != nil{
		logger.Error("Error",err)
		return false,err
	}
	var albumDetails AlbumDetails
	errDb := DBConnection.QueryExecutorByOne(query,"album",&albumDetails);if errDb != nil{
		logger.Error("Error",errDb)
		return false,errDb
	}
	if  albumDetails.MaxImageLimit>0 {
		if uploadedImg < albumDetails.MaxImageLimit {
			return  true,nil
		}
	}
	defer logger.Info("validateImagecount Ends")
	return result,nil
}

func imageCount(value string)(int,error){
	logger.Info("imageCount starts")
	query := make(map[string]interface{})
	query = bson.M{"albumId":value}
	uploadedImg, err := DBConnection.CountQueryExecutor(query,"image");if err != nil{
		logger.Error("Error",err)
		return uploadedImg,err
	}
	defer logger.Info("validateImagecount Ends")
	return uploadedImg,nil
}

func ReturnJSONAPIError(w http.ResponseWriter, err error, errorCode int) {
	w.Header().Set("Content-Type", "application/json")
	j, _ := json.Marshal(struct {StatusCode int;Status string;Message string}{StatusCode:errorCode,Status:"FAILED",Message:err.Error()})
	w.Write(j)
	return
}
func ReturnJSONAPISuccess(w http.ResponseWriter,message interface{}, extra interface{}) {
	w.Header().Set("Content-Type", "application/json")
	j, _ := json.Marshal(struct {
		StatusCode int
		Status string
		Message interface{} `json:"Message,omitempty"`
		Extra  interface{} `json:"Extra,omitempty"`
	}{StatusCode: 200, Status: "SUCCESS", Message:message,Extra: extra})
	w.Write(j)
	return
}
