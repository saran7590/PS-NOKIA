package DBConnection

import (
	"errors"
	"gopkg.in/mgo.v2"
	"strings"
	"time"
)

const (
	hosts      = "mongodb:27017"
	database   = "db"
	username   = ""
	password   = ""
	image_collection = "imageDetails"
	album_collection = "albumDetails"
)

type MongoStore struct {
	session *mgo.Session
}

var mongoStore = MongoStore{}

func initialiseMongo() (session *mgo.Session) {
	info := &mgo.DialInfo{
		Addrs:    []string{hosts},
		Timeout:  60 * time.Second,
		Database: database,
		Username: username,
		Password: password,
	}
	session, err := mgo.DialWithInfo(info)
	if err != nil {
		logger.Error("Error during DB dial connection",err)
		panic(err)
	}
	return

/*	if w.session == nil {
		var err error
		session, err := mgo.Dial(w.Username + ":" + w.Password + "@" + w.Host + ":" + w.Port)
		//session, err := mgo.Dial(w.Host + ":" + w.Port)
		if err != nil {
			return nil, fmt.Errorf("error loading mondo db %v", err)
		} else {
			w.session = session
		}
	}
	return w.session.Copy(), nil*/
}
func CountQueryExecutor(query interface{},collection string)(int,error){
	session := initialiseMongo()
	mongoStore.session = session
	collection1 := ""
	if collection == "image"{
		collection1 = image_collection
	}else{
		collection1 = album_collection
	}
	col := mongoStore.session.DB(database).C(collection1)
	count, errMongo := col.Find(query).Count()
	if errMongo != nil {
		if strings.Contains(errMongo.Error(), "not found") {
			return  0,errors.New("No record found")
		}else{
			return 0,errMongo
		}
	}
	defer session.Close()
	//defer logger.Info("Validation Ends")
	return count,nil
}

func QueryExecutorByOne(query interface{},collectionType string, result interface{})(error){
	logger.Info("QueryExecutorByOne--->Before Query")
	session := initialiseMongo()
	mongoStore.session = session
	collectionName := ""
	if collectionType == "image"{
		collectionName = image_collection
	}else{
		collectionName = album_collection
	}
	col := mongoStore.session.DB(database).C(collectionName)
	errMongo := col.Find(query).One(result)
	logger.Info("QueryExecutorByOne--->Query Ends")
	if errMongo != nil {
		if strings.Contains(errMongo.Error(), "not found") {
			return  errors.New("No data found")
		}else{
			return errMongo
		}
	}
	logger.Info("QueryExecutorByOne--->Before Ends")
	defer session.Close()
	//defer logger.Info("Validation Ends")
	return nil
}

func CountRecordByAlbumIDAndImageId(query interface{},collection string)(int,error){
	session := initialiseMongo()
	mongoStore.session = session
	col := mongoStore.session.DB(database).C(image_collection)
	count, errMongo := col.Find(query).Count()
	if errMongo != nil {
		if strings.Contains(errMongo.Error(), "not found") {
			return  0,errors.New("No record found")
		}else{
			return 0,errMongo
		}
	}
	defer session.Close()
	//defer logger.Info("Validation Ends")
	return count,nil

}
func QueryExecutorByAll(query interface{},collectionType string, result interface{})(error){
	session := initialiseMongo()
	mongoStore.session = session
	collectionName := ""
	if collectionType == "image"{
		collectionName = image_collection
	}else{
		collectionName = album_collection
	}
	col := mongoStore.session.DB(database).C(collectionName)
	errMongo := col.Find(query).All(result)
	if errMongo != nil {
		if strings.Contains(errMongo.Error(), "not found") {
			return  errors.New("No data found for the search criteria")
		}else{
			return errMongo
		}
	}
	defer session.Close()
	//defer logger.Info("Validation Ends")
	return nil
}
/*fmt.Println("Save to MongoDB")
col := mongoStore.session.DB(database).C(collection)

//Save data into Job struct
var _job UploadImage

query := bson.M{"imageid":inputOrderID,"albumid":bson.M{"$eq":""}}
//Insert job into MongoDB
errMongo := col.Find(query).One(&_job)
if errMongo != nil {
panic(errMongo)
}
*/
